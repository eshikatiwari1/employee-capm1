sap.ui.define(["sap/fe/core/AppComponent"], function (BaseComponent) {
  "use strict";

  /**
   * @namespace my.employee.project1
   */
  const Component = BaseComponent.extend("my.employee.project1.Component", {
    metadata: {
      manifest: "json"
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
