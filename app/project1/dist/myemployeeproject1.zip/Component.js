sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";const n=e.extend("my.employee.project1.Component",{metadata:{manifest:"json"}});return n});
//# sourceMappingURL=Component.js.map